/**
 * Universidad Icesi (Cali - Colombia)
 * Algoritmos y programacion I
 * Seguimiento 12
 * @Author: Daniela Olarte Borja A00368359
 * @Date: 31/10/2020
 */
package ui;
import java.util.Scanner;
import model.VaccineCenter;
public class Main {
    private VaccineCenter center;
    private Scanner sc;
    public Main(){
        sc = new Scanner(System.in);
    }
    public static void main(String[] args) {
        //Declarations
        Main main = new Main();
        main.center = new VaccineCenter();
        int option = 0;
        do{
            main.showMenu();
            option = main.sc.nextInt();
            main.executeOperation(option);
        } while(option != 0);
    }
    public void showMenu(){
        System.out.print("\n"+
            "********Menu**********\n"+
            "1. Add patient********\n"+
            "2. Show patients******\n"+
            "3. Show patients info*\n"+
            "4. Show centers info**\n"+
            "0. Exit***************\n");
    }
    public void executeOperation(int option){
        boolean space = false;
        switch(option){
            case 1:
                space = center.patientsHasSpace();
                if(space == true){
                    showPatientTypeMenu();
                    option = sc.nextInt();
                    executePatientOperation(option);
                } else{
                    System.out.println("Not enough space");
                }
            break;
            case 2:showPatients();
            break;
            case 3:showInformation();
            break;
            case 4:showCenterInformation();
            break;
        }
    }
    public void showPatientTypeMenu(){
        System.out.print(
            "\n********Patient Type******\n"+
            "1. Particular patient*******\n"+
            "2. EPS patient**************\n"+
            "3. Prepaid patient**********\n");
    }
    public void showPrepaidTypeMenu(){
        System.out.print(
            "\n********Prepaid Type********\n"+
            "1. Coomeva********************\n"+
            "2. SURA***********************\n"+
            "3. Other**********************\n"
        );
    }
    public void executePatientOperation(int option){
        switch(option){
            case 1:createParticularPatient();
            break;
            case 2:createEPSPatient();
            break;
            case 3:
                showPrepaidTypeMenu();
                option = sc.nextInt();
                executePrepaidOperation(option);
            break;
        }
    }
    public void executePrepaidOperation(int option){
        switch(option){
            case 1:createCoomevaPatient();
            break;
            case 2:createSuraPatient();
            break;
            case 3:createOtherPatient();
            break;
        }
    }
    public void createParticularPatient(){
        System.out.println("Type in first Name");
        sc.nextLine();
        String firstName = sc.nextLine();
        System.out.println("Type in last name");
        String lastName = sc.nextLine();
        System.out.println("Type in age");
        int age = sc.nextInt();
        System.out.println("Type in ID");
        sc.nextLine();
        String iD = sc.nextLine();
        System.out.println("Type in phone number");
        String tel = sc.nextLine();
        System.out.println("Type in doctors name");
        String dName = sc.nextLine();
        System.out.println("Type in doctors phone number");
        String dTel = sc.nextLine();
        System.out.println("Type in doctors license");
        String licenseID = sc.nextLine();
        center.addPatient(firstName, lastName, age, iD, tel, dName, dTel, licenseID);
    }
    public void createEPSPatient(){
        System.out.println("Type in first Name");
        sc.nextLine();
        String firstName = sc.nextLine();
        System.out.println("Type in last name");
        String lastName = sc.nextLine();
        System.out.println("Type in age");
        int age = sc.nextInt();
        System.out.println("Type in ID");
        sc.nextLine();
        String iD = sc.nextLine();
        System.out.println("Type in EPS");
        String nameEPS = sc.nextLine();
        System.out.println("Type in EPS order number");
        String orderNum = sc.nextLine();
        center.addPatient(firstName, lastName, age, iD, nameEPS, orderNum);
    }
    public void createCoomevaPatient(){
        System.out.println("Type in first Name");
        sc.nextLine();
        String firstName = sc.nextLine();
        System.out.println("Type in last name");
        String lastName = sc.nextLine();
        System.out.println("Type in age");
        int age = sc.nextInt();
        System.out.println("Type in ID");
        sc.nextLine();
        String iD = sc.nextLine();
        System.out.println("Type in membership ID");
        String afiliationID = sc.nextLine();
        System.out.println("Select membership category:");
        System.out.print("1. Platinum \n" + "2. Gold \n" + "3. Gold plus \n");
        String category = "";
        int option = sc.nextInt();
        switch(option){
            case 1:
                category = "PLATINUM";
            break;
            
            case 2:
                category = "GOLD";
            break;

            case 3:
                category = "GOLDPLUS";
            break;
        }
        center.addPrepaidPatient(firstName, lastName, age, iD, afiliationID, category);
    }
    public void createSuraPatient(){
        System.out.println("Type in first Name");
        sc.nextLine();
        String firstName = sc.nextLine();
        System.out.println("Type in last name");
        String lastName = sc.nextLine();
        System.out.println("Type in age");
        int age = sc.nextInt();
        System.out.println("Type in ID");
        sc.nextLine();
        String iD = sc.nextLine();
        System.out.println("Type in membership ID");
        String afiliationID = sc.nextLine();
        System.out.println("Type in minimum rank of the policy");
        double minRank = sc.nextDouble();
        System.out.println("Type in maximum rank of the policy");
        double maxRank = sc.nextDouble();
        center.addPrepaidPatient(firstName, lastName, age, iD, afiliationID, minRank, maxRank);
    }
    public void createOtherPatient(){
        System.out.println("Type in first Name");
        sc.nextLine();
        String firstName = sc.nextLine();
        System.out.println("Type in last name");
        String lastName = sc.nextLine();
        System.out.println("Type in age");
        int age = sc.nextInt();
        System.out.println("Type in ID");
        sc.nextLine();
        String iD = sc.nextLine();
        System.out.println("Type in membership ID");
        String afiliationID = sc.nextLine();
        System.out.println("Type in entity name");
        String entityName = sc.nextLine();
        System.out.println("Type in entity phone number");
        String entityTel = sc.nextLine();
        center.addPrepaidPatient(firstName, lastName, age, iD, afiliationID, entityName, entityTel);
    }
    public void showPatients(){
        String number = "The number of patients is: "+ center.numOfPatients()+ "****************\n" +
                        "The number of particular patients is: "+ center.numOfParticular()+ "***\n" +
                        "The number of EPS patients is: "+ center.numOfEPS()+ "*****************\n" +
                        "The number of prepaid patients is: "+ center.numOfPrepaid()+ "*********\n" +
                        "The number of coomeva prepaid patients is: "+ center.numOfCoomeva()+ "*\n" +
                        "The number of sura prepaid patients is: "+ center.numOfSura()+ "*******\n" +
                        "The number of the rest of prepaid patients is: "+ center.numOfOther()+"\n";
        System.out.print(number);
    }
    public void showInformation(){
        if(center.numOfPatients()==0){
            System.out.println("Not enough patients");
        } else{
            System.out.println("Select patient");
            System.out.println("");
            System.out.print(center.showPatients());
            int option = sc.nextInt();
            System.out.println(center.showPatientInfo(option));
        }
    }
    public void showCenterInformation(){
        if(center.numOfPatients()==0){
            System.out.println("Not enough patients");
        } else{
            System.out.println("Patients: ");
            System.out.print(center.showPatients());
            String number = "The number of patients is: "+ center.numOfPatients()+ "***************\n" +
                            "The number of particular patients is: "+ center.numOfParticular()+ "**\n" +
                            "The number of EPS patients is: "+ center.numOfEPS()+ "****************\n" +
                            "The number of prepaid patients is: "+ center.numOfPrepaid()+ "********\n" +
                            "The number of coomeva prepaid patients is: "+ center.numOfCoomeva()+ "\n" +
                            "The number of sura prepaid patients is: "+ center.numOfSura()+ "******\n" +
                         "The number of the rest of prepaid patients is: "+ center.numOfOther()+ "*\n";
            System.out.print(number);
        }
    }
}

