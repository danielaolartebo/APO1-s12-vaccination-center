package model;
public enum Category {
    PLATINUM, GOLD, GOLDPLUS
}
