package model;
public class Other extends Prepaid{
    private String entityName;
    private String entityTel;
    public Other(String entityName, String entityTel, String afiliationID, String firstName, String lastName, int age, String iD){
        super(afiliationID, firstName, lastName, age, iD);
        this.entityName = entityName;
        this.entityTel = entityTel;
    }
    public String getEntityName() {
        return entityName;
    }
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }
    public String getEntityTel() {
        return entityTel;
    }
    public void setEntityTel(String entityTel) {
        this.entityTel = entityTel;
    }
    public String getInfo(){
        String info = "********Patient************************\n"+
                      "First name: "+getFirstName() +"********\n"+
                      "Last name: "+getLastName() +"**********\n"+
                      "Age: "+getAge() +"*********************\n"+
                      "ID: "+getID() +"***********************\n"+
                      "Afiliation ID: "+getAfiliationID()+"***\n"+
                      "Entity name: "+getEntityName()+"*******\n"+
                      "Entity phone number: "+getEntityTel()+"\n";
        return info;
    }
}
