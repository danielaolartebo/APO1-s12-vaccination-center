package model;
public class EPS extends Patient{
    private String nameEPS;
    private String orderNum;
    public EPS(String firstName, String lastName, int age, String iD, String nameEPS, String orderNum){
        super(firstName, lastName, age, iD);
        this.nameEPS = nameEPS;
        this.orderNum = orderNum;
    }
    public String getNameEPS() {
        return nameEPS;
    }
    public void setNameEPS(String nameEPS) {
        this.nameEPS = nameEPS;
    }
    public String getOrderNum() {
        return orderNum;
    }
    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }
    public String getInfo(){
        String info = "********Patient********\n"+
                      "First name: "+getFirstName() +"\n"+
                      "Last name: "+getLastName() +"\n"+
                      "Age: "+getAge() +"\n"+
                      "ID: "+getID() +"\n"+
                      "EPS name : "+getNameEPS() +"\n"+
                      "Order number: "+getOrderNum() +"\n";
        return info;
    }
}
