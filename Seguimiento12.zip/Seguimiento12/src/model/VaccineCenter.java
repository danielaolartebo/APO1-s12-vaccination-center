package model;
public class VaccineCenter{
    public final int MAX_VACCINES = 30;
    public final int MAX_PATIENTS = 300;
    private Patient[] patients;
    public VaccineCenter(){
        patients = new Patient[MAX_PATIENTS];
    }
    public boolean patientsHasSpace(){
        boolean space = false;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] == null){
                space = true;
            }
        }
        return space;
    }
    public int patientsFindSpace(){
        boolean founded = false;
        int index = 0;
        for(int i = 0; i<MAX_PATIENTS && founded == false; i++){
            if(patients[i] == null){
                founded = true;
                index = i;
            }
        }
        return index;
    }
    public void addPatient(String firstName, String lastName, int age, String iD, String tel, String doctorName, String doctorTel, String doctorLicense){
        int index = patientsFindSpace();
        patients[index] = new Particular(firstName, lastName, age, iD, tel, doctorName, doctorTel, doctorLicense);
    }
    public void addPatient(String firstName, String lastName, int age, String iD, String nameEPS, String orderNum){
        int index = patientsFindSpace();
        patients[index] = new EPS(firstName, lastName, age, iD, nameEPS, orderNum);
    }
    public void addPrepaidPatient(String firstName, String lastName, int age, String iD, String afiliationID, String category){
        int index = patientsFindSpace();
        patients[index] = new Coomeva(category, afiliationID, firstName, lastName, age, iD);
    }
    public void addPrepaidPatient(String firstName, String lastName, int age, String iD, String afiliationID, double maxRank, double minRank){
        int index = patientsFindSpace();
        patients[index] = new Sura(maxRank, minRank, afiliationID, firstName, lastName, age, iD);
    }
    public void addPrepaidPatient(String firstName, String lastName, int age, String iD, String afiliationID, String entityName, String entityTel){
        int index = patientsFindSpace();
        patients[index] = new Other(entityName, entityTel, afiliationID, firstName, lastName, age, iD);
    }
    public int numOfPatients(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] != null){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfParticular(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof Particular){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfEPS(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof EPS){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfPrepaid(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof Prepaid){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfCoomeva(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof Coomeva){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfSura(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof Sura){
                quantity++;
            }
        }
        return quantity;
    }
    public int numOfOther(){
        int quantity = 0;
        for(int i = 0; i<MAX_PATIENTS; i++){
            if(patients[i] instanceof Other){
                quantity++;
            }
        }
        return quantity;
    }
    public String showPatients(){
        String patientsInfo = "********Patients********\n";
        for(int i = 0; i<numOfPatients(); i++){
            patientsInfo += (i+1)+". "+patients[i].getFirstName()+" "+patients[i].getLastName()+"\n";
        }
        return patientsInfo;
    }
    public String showPatientInfo(int index){
        String info = patients[(index-1)].getInfo();
        return info;
    }
}