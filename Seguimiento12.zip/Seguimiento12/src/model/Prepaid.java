package model;
public abstract class Prepaid extends Patient{
    private String afiliationID;
    public Prepaid(String afiliationID, String firstName, String lastName, int age, String iD){
        super(firstName, lastName, age, iD);
        this.afiliationID = afiliationID;
    }
    public String getAfiliationID() {
        return afiliationID;
    }
    public void setAfiliationID(String afiliationID) {
        this.afiliationID = afiliationID;
    }
    public String getInfo(){
        String info = "********Patient*********************\n"+
                      "First name: "+getFirstName() +"*****\n"+
                      "Last name: "+getLastName() +"*******\n"+
                      "Age: "+getAge() +"******************\n"+
                      "ID: "+getID() +"********************\n"+
                      "Afiliation ID: "+getAfiliationID()+"\n";
        return info;
    }
}
