package model;
public class Sura extends Prepaid{
    private double maxRank;
    private double minRank;
    private double policyRank;
    public Sura(double maxRank, double minRank, String afiliationID, String firstName, String lastName, int age, String iD){
        super(afiliationID, firstName, lastName, age, iD);
        this.maxRank = maxRank;
        this.minRank = minRank;
        this.policyRank = (maxRank + minRank)/2;
    }
    public double getMaxRank() {
        return maxRank;
    }
    public void setMaxRank(double maxRank) {
        this.maxRank = maxRank;
    }
    public double getMinRank() {
        return minRank;
    }
    public void setMinRank(double minRank) {
        this.minRank = minRank;
    }
    public double getPolicyRank() {
        return policyRank;
    }

    public void setPolicyRank(double policyRank) {
        this.policyRank = policyRank;
    }
    public String getInfo(){
        String info = "********Patient**********************\n"+
                      "First name: "+getFirstName() +"******\n"+
                      "Last name: "+getLastName() +"********\n"+
                      "Age: "+getAge() +"*******************\n"+
                      "ID: "+getID() +"*********************\n"+
                      "Afiliation ID: "+getAfiliationID() +"\n"+
                      "Policy rank: "+getPolicyRank()+"*****\n";
        return info;
    }
}
