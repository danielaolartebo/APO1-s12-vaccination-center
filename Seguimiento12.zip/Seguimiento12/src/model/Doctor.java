package model;

public class Doctor {
    //Atributes
    private String name;
    private String tel;
    private String licenseID;

    //Builder
    public Doctor(String name, String tel, String licenseID){
        this.name = name;
        this.tel = tel;
        this.licenseID = licenseID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getLicenseID() {
        return licenseID;
    }

    public void setLicenseID(String licenseID) {
        this.licenseID = licenseID;
    }

    public String toString(){
        String info = "********Doctor********\n"+
                      "Name: "+getName()+"\n"+
                      "Phone number: "+getTel()+"\n"+
                      "License ID: "+getLicenseID()+"\n";
        return info;
    }
}
