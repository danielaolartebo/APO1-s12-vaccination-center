package model;
public class Coomeva extends Prepaid{
    private Category category;
    public Coomeva(String category, String afiliationID, String firstName, String lastName, int age, String iD){
        super(afiliationID, firstName, lastName, age, iD);
        Category aCategory = Category.valueOf(category);
        this.category = aCategory;
    }
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    public String getInfo(){
        String info = "********Patient**********************\n"+
                      "First name: "+getFirstName() +"******\n"+
                      "Last name: "+getLastName() +"********\n"+
                      "Age: "+getAge() +"*******************\n"+
                      "ID: "+getID() +"*********************\n"+
                      "Afiliation ID: "+getAfiliationID() +"\n"+
                      "Category: "+getCategory()+"**********\n";
        return info;
    }
}
