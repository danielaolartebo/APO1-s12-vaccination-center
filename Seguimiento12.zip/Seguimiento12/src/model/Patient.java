package model;
public abstract class Patient {
    public final int MAX_DOSES = 100;
    private String firstName;
    private String lastName;
    private int age;
    private String iD;
    public Patient(String firstName, String lastName, int age, String iD){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.iD = iD;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getID() {
        return iD;
    }
    public void setID(String iD) {
        this.iD = iD;
    }
    public String getInfo(){
        String info = "********Patient****************\n"+
                      "First name: "+getFirstName() +"\n"+
                      "Last name: "+getLastName() +"**\n"+
                      "Age: "+getAge() +"*************\n"+
                      "ID: "+getID() +"***************\n";
        return info;
    }
}
