package model;

public class Particular extends Patient{
    //Atributes
    private String tel;

    //Relationships
    private Doctor doctor;

    //Builder
    public Particular(String firstName, String lastName, int age, String iD, String tel, String doctorName, String doctorTel, String doctorLicense){
        super(firstName, lastName, age, iD);
        this.tel = tel;
        doctor = new Doctor(doctorName, doctorTel, doctorLicense);
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public String getInfo(){
        String info = "********Patient********\n"+
                      "First name: "+getFirstName() +"\n"+
                      "Last name: "+getLastName() +"\n"+
                      "Age: "+getAge() +"\n"+
                      "ID: "+getID() +"\n"+
                      "Phone number : "+getTel() +"\n"+
                      "ID: "+getID() +"\n"+"\n"+
                      doctor.toString();
        return info;
    }
}
